<?php
include 'NameSpace.php';
include 'connexion.php';
$Bien = new location\dao\Biens();
$Prop = new location\dao\Proprietaires();


if (isset($_POST['Enregistrer'])){
    extract($_POST);
    $Bien->NomBien = $NomBien;
    $Bien->Addresse = $Addresse;
    //$Bien->Password = $Password;
   // $Bien->Price = $Price;
    $Bien->Commission = $Commission;
    $Bien->Etat = $Etat;
    $Bien->IdType = $IdType;
    $Bien->IdProp = $IdProp;
    $Prop->NumeroPiece = $NumeroPiece;
    $Prop->NomProp = $NomProp;
    $Prop->CellPhone = $CellPhone ;
    $ligneTest = $bdd->query('SELECT * FROM Propriétaires WHERE  NumeroPiece = "'.$NumeroPiece.'" ');
$exist=true;                        //verifier si le nouveau employé existe dans notre base de donnée
if($donneeTest = $ligneTest->fetch())
{
    $exist=true;
                        //Ce nom existe dans notre base de donnée
}
else
{
    $exist=false;
    $Prop->addProprietaire();
    //Ce nom n'éxiste pas dans notre base de donnée
}



if($exist==true)                    // Si le nouveau nom existe dans notre base de donnnée alors execute tout les lignes qui sont dans le if
{
    echo "<h6 style='width: 800px; margin: auto; border-bottom: 1px solid black;'>Un utilisateur nommé <span>".$donneeTest['NomProp']."</span> existe dans notre base de donnée avec <span>le même login</span> que vous nous avez renseigner !</h6>";
}
if ($exist==false) {
    $Bien->addBien();
   
    echo 'Bienvenue'.$NomBien.'<br/>'.$NomProp;
                }
/*include 'connexion.php';
include 'SpaceName.php';
$Bien = new location\dao\Biens();
if(isset($_POST['Enregistrer']))
                {
                    extract($_POST);
                    $Bien->IdBien = $IdBien;
                    $Bien->NomBien = $NomBien;
    $Bien->Addresse = $Addresse;
    //$Bien->Password = $Password;
    $Bien->Price = $Price;
    $Bien->Commission = $Commission;
    $Bien->Etat = $Etat;
    $Bien->IdType = $IdType;
    $dat=('UPDATE Biens SET NomBien=''.$NomBien.'' ,Addresse=''.$Addresse.'',Price=''.$Price.'',Commission=''.$Commission.'',Etat=.''.$Etat.'',IdType=''.$IdType.'' from Biens where IdBien=''.$IdBien.''');
    $Bien->modifBien();
                }
                ?>*/
            }
   // $User->addUser();
    //Ce nom n'éxiste pas dans notre base de donnée
        
    



  //include 'AccueilUtilisateur.php';
   // header('location:AccueilUtilisateur.php');
else {
    echo 'Veuillez entrer vos infos';
}
?>