<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Bootstrap 3 Contact form with Validation</title>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js" type="text/javascript"></script>

  
  <link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css'>
<link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap-theme.min.css'>
<link rel='stylesheet prefetch' href='http://cdnjs.cloudflare.com/ajax/libs/jquery.bootstrapvalidator/0.5.0/css/bootstrapValidator.min.css'>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js'></script>
<script src='http://cdnjs.cloudflare.com/ajax/libs/bootstrap-validator/0.4.5/js/bootstrapvalidator.min.js'></script>

      <link rel="stylesheet" href="css/style.css">

  
</head>
<script src="form.js"></script>
<body>

  <div class="container">

    <form class="well form-horizontal" action="connecte1.php" method="post"  id="contact_form">
<fieldset>

<!-- Form Name -->
<legend>Contrat de Bien</legend>

<!-- Text input-->

<div class="form-group">
  <label class="col-md-4 control-label">Nom du Bien</label>  
  <div class="col-md-4 inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
  <input  name="NomBien" placeholder="nom du bien" class="form-control"  type="text">
    </div>
  </div>
</div>
<div class="form-group">
  <label class="col-md-4 control-label">Addresse</label>  
    <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
        <span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span>
  <input name="Addresse" placeholder="Adress" class="form-control"  type="text">
    </div>
  </div>
</div>
<div class="form-group">
  <label class="col-md-4 control-label" >Commission</label> 
    <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-euro"></i></span>
  <input name="Commission" placeholder="Montant de la Location" class="form-control"  type="text">
    </div>
  </div>
</div>
<div class="form-group">
  <label class="col-md-4 control-label" >Prix</label> 
    <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-euro"></i></span>
  <input name="Price" placeholder="Montant de la Location" class="form-control"  type="text">
    </div>
  </div>
</div>
<div class="form-group"> 
  <label class="col-md-4 control-label">Type de Bien</label>
    <div class="col-md-4 selectContainer">
    <div class="input-group">
        <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
   <select class='form-group custom-select form-control' id='IdType' style='margin-left: 0px;width: 243px; height: 35px;border-radius:0px' name='IdType' required='required' >
            <option value="" >Séléctionner le type de bien</option>
            <?php
        include 'connexion.php';
        $ligne0 = $bdd->query('SELECT Nom, IdType FROM TypeBien');
        while ($donnee0 = $ligne0->fetch())
        {
        ?>
            <option value="<?php echo $donnee0['IdType'];?>"> <?php echo $donnee0['Nom'];?> </option>
        <?php
        }
        ?>
        </select><br/>
    
 
  </div>
</div>
</div>

      
                  <fieldset>
                  <div  id="form_prop">
                  <!-- Form Name -->


                  <!-- Text input-->

                  <div class="form-group">
                    <label class="col-md-4 control-label">Nom</label>  
                    <div class="col-md-4 inputGroupContainer">
                    <div class="input-group">
                    <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                    <input  name="NomProp" placeholder="Votre nom" class="form-control"  type="text" style="width:243px;">
                      </div>
                    </div>
                  </div>

                  <div class="form-group">
                    <label class="col-md-4 control-label">Numero Piece</label>  
                    <div class="col-md-4 inputGroupContainer">
                    <div class="input-group">
                    <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                    <input  name="NumeroPiece" placeholder="numPiece" class="form-control"  type="text" style="width:243px;">
                      </div>
                    </div>
                  </div>





                  <!-- Text input-->
                         
                  <div class="form-group">
                    <label class="col-md-4 control-label">Telephone</label>  
                      <div class="col-md-4 inputGroupContainer">
                      <div class="input-group">
                          <span class="input-group-addon"><i class="glyphicon glyphicon-earphone"></i></span>
                    <input name="CellPhone" placeholder="(+221)00-000-00-00" class="form-control" type="text" style="width:243px;">
                      </div>
                    </div>
                  </div>
                  </div>
                       







                            
     
<!-- Text area -->
<!-- Text input-->

<div class="form-group" id="montant">
  <label class="col-md-4 control-label" >Montant Location</label> 
    <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-euro"></i></span>
  <input name="MontantLocation" placeholder="Montant de la Location" class="form-control"  type="text">
    </div>
  </div>
</div>


      
<div class="form-group">
  <label class="col-md-4 control-label">Date debut du contrat</label>  
    <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
        <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
  <input id="datedb" name="DateDebut" placeholder="Address" class="form-control" type="date" style="height:50px">
    </div>
  </div>
</div>
<div class="form-group">
  <label class="col-md-4 control-label">Date fin du contrat</label>  
    <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
        <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
  <input id="datefin" name="DateFin" placeholder="Address" class="form-control" type="date" style="height:50px">
    </div>
  </div>
</div>


   


<!-- Text input-->




<!-- radio checks -->

  
<div class="form-group">
  <label class="col-md-4 control-label">Termes du Contrat</label>
    <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
        <span class="input-group-addon"><i class="glyphicon glyphicon-pencil"></i></span>
            <?php
             include 'connexion.php';
                $sql = "SELECT `Text` FROM `TextContrat` WHERE IdText = 1";
                $req = $bdd->query($sql);
                while($data = $req->fetch()){
          ?>
          
          <textarea class="form-control" name="comment" style="height:100px" placeholder="" readonly>
          <?php echo $data['Text'] ?>
          </textarea>
          <?php
                }
                ?>

  </div>
  <div class="radio">
                                <label>
                                    <input type="radio" name="textCont" value="oui" /> Acceptez
                                </label>
                          
                          
                                <label>
                                    <input type="radio" name="textCont" value="no" /> Refuser
                                </label>
                            </div>
                            <input type="submit" class="btn btn-warning" name="valider" value="Enregistrer">
  </div>
</div>

<!-- Success message -->
<div class="alert alert-success" role="alert" id="success_message">Success <i class="glyphicon glyphicon-thumbs-up"></i> Thanks for contacting us, we will get back to you shortly.</div>

<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label"></label>
  <div class="col-md-4">
  </div>
</div>

</fieldset>
</form>
<span class="glyphicon glyphicon-send"></span>

</div>
    </div><!-- /.container -->
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js'></script>
<script src='http://cdnjs.cloudflare.com/ajax/libs/bootstrap-validator/0.4.5/js/bootstrapvalidator.min.js'></script>

  

   <!-- <script  src="js/index.js"></script>-->




</body>
</html>
