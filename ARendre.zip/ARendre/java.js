
$(document).ready(function() {            
                    function champObligatoire(champ) {
                      if (champ.val() == "") {

                          return "Veuillez Remplir le champ " + champ.attr("val-champ");
                      } else

                          return "";
                  }
                        $('#contact_form').on('submit', function(e) {
                     e.preventDefault();
                       var formData = $(this).serialize();   // retourne une chaîne au format champ1=valeur1&champ2=valeur2..
                    console.log(formData);
                        //var champs = $("#con input:text,#con input:password");
                     



                        $.ajax({
                            type: "POST",
                            url: "connecte1.php",
                            data: dataString,
                            /* UNCOMMNENT TO SEND TO CONSOLE */
                            /*
                            console.log (dataString);   
                            console.log ("AJAX DONE");
                            */
                            success: function(server_reponse) {
                                console.log(server_reponse);
                                /* UNCOMMNENT TO SEND TO CONSOLE */
                                /*
                                console.log (dataString);   
                                console.log ("AJAX DONE");
                                */
                            }
                        });

                            


                     });   
                       
                       
                   });     //EOC
 
   
     //EOF
